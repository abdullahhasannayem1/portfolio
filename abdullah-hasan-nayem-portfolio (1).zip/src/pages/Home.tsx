import { motion } from 'motion/react';
import { ArrowRight, Code, Rocket, Database } from 'lucide-react';
import { Link } from 'react-router-dom';
import GlassCard from '../components/GlassCard';

export default function Home() {
  return (
    <div className="relative overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-secondary/20 rounded-full blur-[120px] animate-pulse delay-700" />
      </div>

      {/* Hero Section */}
      <section className="min-h-[90vh] flex flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-6 inline-block px-4 py-1.5 rounded-full glass text-xs font-semibold tracking-widest uppercase text-primary"
        >
          Available for new opportunities
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-8xl font-black tracking-tighter text-white mb-6 leading-[0.9]"
        >
          Abdullah Hasan <br />
          <span className="text-gradient">Nayem</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-2xl text-lg md:text-xl text-slate-400 mb-10 leading-relaxed"
        >
          Full-stack developer, entrepreneur, and tech enthusiast. 
          Crafting high-performance web applications and exploring the future of technology.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6"
        >
          <Link
            to="/projects"
            className="px-8 py-4 bg-primary text-white rounded-full font-bold flex items-center justify-center space-x-2 hover:bg-blue-600 transition-all hover:scale-105"
          >
            <span>View Projects</span>
            <ArrowRight size={20} />
          </Link>
          <Link
            to="/contact"
            className="px-8 py-4 glass text-white rounded-full font-bold flex items-center justify-center hover:bg-white/10 transition-all hover:scale-105"
          >
            Contact Me
          </Link>
        </motion.div>
      </section>

      {/* Features/Stats Section */}
      <section className="max-w-7xl mx-auto px-6 py-24 grid grid-cols-1 md:grid-cols-3 gap-8">
        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-primary/10 rounded-2xl mb-6">
            <Code className="text-primary" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Modern Tech</h3>
          <p className="text-slate-400">
            Expertise in React, Node.js, and modern cloud infrastructures.
          </p>
        </GlassCard>

        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-secondary/10 rounded-2xl mb-6">
            <Rocket className="text-secondary" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Scalable Apps</h3>
          <p className="text-slate-400">
            Building applications that grow with your business needs.
          </p>
        </GlassCard>

        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-accent/10 rounded-2xl mb-6">
            <Database className="text-accent" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Data Driven</h3>
          <p className="text-slate-400">
            Leveraging data to create personalized and efficient user experiences.
          </p>
        </GlassCard>
      </section>
    </div>
  );
}
