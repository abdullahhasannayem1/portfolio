import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { Plus, Edit2, Trash2, X, Save, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatDate } from '../lib/utils';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  category: string;
  tags: string[];
  status: 'draft' | 'published';
  image: string;
  createdAt: any;
}

export default function AdminBlogs() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    excerpt: '',
    category: '',
    tags: '',
    status: 'draft' as 'draft' | 'published',
    image: ''
  });

  const fetchPosts = async () => {
    try {
      const data = await api.getBlogs();
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleOpenModal = (post?: BlogPost) => {
    if (post) {
      setEditingPost(post);
      setFormData({
        title: post.title,
        content: post.content,
        excerpt: post.excerpt || '',
        category: post.category || '',
        tags: post.tags?.join(', ') || '',
        status: post.status,
        image: post.image || ''
      });
    } else {
      setEditingPost(null);
      setFormData({
        title: '',
        content: '',
        excerpt: '',
        category: '',
        tags: '',
        status: 'draft',
        image: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const postData = {
      ...formData,
      tags: formData.tags.split(',').map(s => s.trim()).filter(s => s !== '')
    };

    try {
      if (editingPost) {
        await api.updateBlog(editingPost.id, postData);
      } else {
        await api.createBlog(postData);
      }
      setIsModalOpen(false);
      fetchPosts();
    } catch (error) {
      console.error('Error saving post:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      try {
        await api.deleteBlog(id);
        fetchPosts();
      } catch (error) {
        console.error('Error deleting post:', error);
      }
    }
  };

  if (loading) return <div className="text-white">Loading posts...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">Manage Blog Posts</h3>
        <button 
          onClick={() => handleOpenModal()}
          className="px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center space-x-2 hover:bg-blue-600 transition-all"
        >
          <Plus size={20} />
          <span>Create Post</span>
        </button>
      </div>

      <div className="space-y-4">
        {posts.map((post) => (
          <GlassCard key={post.id} className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-white/5 flex items-center justify-center">
                  {post.image ? (
                    <img src={post.image} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <FileText className="text-slate-500" size={24} />
                  )}
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-1">{post.title}</h4>
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    <span className="text-primary font-bold uppercase tracking-widest">{post.category}</span>
                    <span>{formatDate(post.createdAt)}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      post.status === 'published' ? 'bg-green-400/10 text-green-400' : 'bg-amber-400/10 text-amber-400'
                    }`}>
                      {post.status}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleOpenModal(post)}
                  className="p-3 hover:bg-white/10 rounded-xl text-slate-400 hover:text-white transition-all"
                >
                  <Edit2 size={18} />
                </button>
                <button 
                  onClick={() => handleDelete(post.id)}
                  className="p-3 bg-red-400/10 text-red-400 hover:bg-red-400/20 rounded-xl transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <GlassCard className="p-10">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-bold text-white">{editingPost ? 'Edit Post' : 'Create New Post'}</h3>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full text-slate-400">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Title</label>
                      <input 
                        type="text" 
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Category</label>
                      <input 
                        type="text" 
                        value={formData.category}
                        onChange={(e) => setFormData({...formData, category: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                        placeholder="Tech, Lifestyle, etc."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Status</label>
                      <select 
                        value={formData.status}
                        onChange={(e) => setFormData({...formData, status: e.target.value as 'draft' | 'published'})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary appearance-none"
                      >
                        <option value="draft" className="bg-slate-900">Draft</option>
                        <option value="published" className="bg-slate-900">Published</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Excerpt</label>
                      <textarea 
                        rows={2}
                        value={formData.excerpt}
                        onChange={(e) => setFormData({...formData, excerpt: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary resize-none"
                        placeholder="Short summary of the post..."
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Content (Markdown supported)</label>
                      <textarea 
                        required
                        rows={10}
                        value={formData.content}
                        onChange={(e) => setFormData({...formData, content: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary font-mono text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Image URL</label>
                      <input 
                        type="text" 
                        value={formData.image}
                        onChange={(e) => setFormData({...formData, image: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Tags (comma separated)</label>
                      <input 
                        type="text" 
                        value={formData.tags}
                        onChange={(e) => setFormData({...formData, tags: e.target.value})}
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                        placeholder="react, coding, tutorial"
                      />
                    </div>
                  </div>

                  <div className="pt-4">
                    <button 
                      type="submit"
                      className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 transition-all"
                    >
                      <Save size={20} />
                      <span>{editingPost ? 'Update Post' : 'Publish Post'}</span>
                    </button>
                  </div>
                </form>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
