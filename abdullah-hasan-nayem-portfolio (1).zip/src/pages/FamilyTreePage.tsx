import FamilyTree from '../components/FamilyTree';

export default function FamilyTreePage() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-24 min-h-screen">
      <div className="mb-12">
        <h2 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tighter">
          Family <span className="text-gradient">Tree</span>
        </h2>
        <p className="text-slate-400 max-w-2xl">
          Explore the roots and connections of the Abdullah Hasan Nayem family. 
          Interactive visualization powered by D3.js. Click on a member to view their profile.
        </p>
      </div>
      
      <div className="h-[700px]">
        <FamilyTree />
      </div>
    </div>
  );
}
