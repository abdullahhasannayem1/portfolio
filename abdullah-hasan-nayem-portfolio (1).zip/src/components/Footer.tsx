import { Github, Linkedin, Twitter, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-400 py-12 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <h3 className="text-2xl font-bold text-white mb-4 tracking-tighter">AHN.</h3>
          <p className="text-sm leading-relaxed">
            Abdullah Hasan Nayem – Developer & Entrepreneur. 
            Building modern web experiences with a focus on performance and user experience.
          </p>
        </div>
        
        <div>
          <h4 className="text-white font-semibold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            <li><a href="/projects" className="hover:text-primary transition-colors">Projects</a></li>
            <li><a href="/blog" className="hover:text-primary transition-colors">Blog</a></li>
            <li><a href="/family-tree" className="hover:text-primary transition-colors">Family Tree</a></li>
            <li><a href="/contact" className="hover:text-primary transition-colors">Contact</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-semibold mb-4">Connect</h4>
          <div className="flex space-x-4">
            <a href="#" className="p-2 glass rounded-full hover:bg-white/20 transition-all"><Github size={20} /></a>
            <a href="#" className="p-2 glass rounded-full hover:bg-white/20 transition-all"><Linkedin size={20} /></a>
            <a href="#" className="p-2 glass rounded-full hover:bg-white/20 transition-all"><Twitter size={20} /></a>
            <a href="mailto:contact@example.com" className="p-2 glass rounded-full hover:bg-white/20 transition-all"><Mail size={20} /></a>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/5 text-center text-xs">
        <p>&copy; {new Date().getFullYear()} Abdullah Hasan Nayem. All rights reserved.</p>
      </div>
    </footer>
  );
}
