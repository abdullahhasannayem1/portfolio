import { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { api } from '../services/api';
import GlassCard from './GlassCard';
import { X } from 'lucide-react';
import { motion } from 'motion/react';

interface FamilyMember {
  id: string;
  name: string;
  photo?: string;
  gender?: 'male' | 'female' | 'other';
  father_id?: string;
  mother_id?: string;
  spouse_id?: string;
  birth_date?: string;
  bio?: string;
}

export default function FamilyTree() {
  const svgRef = useRef<SVGSVGElement>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const data = await api.getFamily();
        setMembers(data);
      } catch (error) {
        console.error('Error fetching family members:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchMembers();
  }, []);

  useEffect(() => {
    if (loading || members.length === 0 || !svgRef.current) return;

    const width = 1000;
    const height = 600;

    // Clear previous SVG content
    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3.select(svgRef.current)
      .attr('viewBox', [0, 0, width, height])
      .attr('width', '100%')
      .attr('height', height)
      .style('cursor', 'grab');

    const g = svg.append('g');

    // Zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.5, 3])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      });

    svg.call(zoom);

    // Prepare hierarchical data
    // For simplicity, we'll use a tree layout starting from the oldest member (no father/mother)
    const rootMember = members.find(m => !m.father_id && !m.mother_id) || members[0];
    
    const stratify = d3.stratify<FamilyMember>()
      .id(d => d.id)
      .parentId(d => d.father_id || d.mother_id || null);

    try {
      const root = stratify(members);
      const treeLayout = d3.tree<FamilyMember>().size([width - 200, height - 200]);
      treeLayout(root);

      // Links
      g.append('g')
        .attr('fill', 'none')
        .attr('stroke', '#3b82f6')
        .attr('stroke-opacity', 0.4)
        .attr('stroke-width', 2)
        .selectAll('path')
        .data(root.links())
        .join('path')
        .attr('d', d3.linkVertical<any, any>()
          .x(d => d.x + 100)
          .y(d => d.y + 100));

      // Nodes
      const node = g.append('g')
        .selectAll('g')
        .data(root.descendants())
        .join('g')
        .attr('transform', d => `translate(${d.x + 100},${d.y + 100})`)
        .on('click', (event, d) => {
          setSelectedMember(d.data);
        })
        .style('cursor', 'pointer');

      node.append('circle')
        .attr('fill', '#1e293b')
        .attr('stroke', d => d.data.gender === 'female' ? '#ec4899' : '#3b82f6')
        .attr('stroke-width', 3)
        .attr('r', 40);

      node.append('clipPath')
        .attr('id', d => `clip-${d.id}`)
        .append('circle')
        .attr('r', 38);

      node.append('image')
        .attr('xlink:href', d => d.data.photo || `https://picsum.photos/seed/${d.id}/100/100`)
        .attr('x', -38)
        .attr('y', -38)
        .attr('width', 76)
        .attr('height', 76)
        .attr('clip-path', d => `url(#clip-${d.id})`)
        .attr('preserveAspectRatio', 'xMidYMid slice');

      node.append('text')
        .attr('dy', 60)
        .attr('text-anchor', 'middle')
        .attr('fill', 'white')
        .attr('font-size', '12px')
        .attr('font-weight', 'bold')
        .text(d => d.data.name);

    } catch (e) {
      console.error('Error creating tree:', e);
      // Fallback: simple list or message
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height / 2)
        .attr('text-anchor', 'middle')
        .attr('fill', 'white')
        .text('Could not build tree structure. Check relationships.');
    }

  }, [loading, members]);

  if (loading) return <div className="text-white">Loading family tree...</div>;

  const spouse = selectedMember?.spouse_id ? members.find(m => m.id === selectedMember.spouse_id) : null;

  return (
    <div className="relative w-full h-full">
      <div className="glass-dark rounded-3xl overflow-hidden border border-white/10">
        <svg ref={svgRef} className="w-full h-full" />
      </div>

      {selectedMember && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md w-full"
          >
            <GlassCard className="relative p-8">
              <button 
                onClick={() => setSelectedMember(null)}
                className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition-colors text-white"
              >
                <X size={20} />
              </button>
              
              <div className="flex flex-col items-center text-center">
                <div className={`w-32 h-32 rounded-full overflow-hidden border-4 ${selectedMember.gender === 'female' ? 'border-pink-500' : 'border-primary'} mb-6`}>
                  <img 
                    src={selectedMember.photo || `https://picsum.photos/seed/${selectedMember.id}/200/200`} 
                    alt={selectedMember.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h3 className="text-2xl font-bold text-white mb-1">{selectedMember.name}</h3>
                <p className="text-slate-500 text-xs uppercase tracking-widest mb-4">{selectedMember.gender}</p>
                
                {spouse && (
                  <div className="mb-4 p-3 glass rounded-xl border border-white/10 w-full">
                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Spouse</p>
                    <div className="flex items-center justify-center space-x-3">
                      <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
                        <img src={spouse.photo || `https://picsum.photos/seed/${spouse.id}/50/50`} alt={spouse.name} className="w-full h-full object-cover" />
                      </div>
                      <span className="text-white font-medium text-sm">{spouse.name}</span>
                    </div>
                  </div>
                )}

                {selectedMember.birth_date && (
                  <p className="text-primary text-sm font-medium mb-4">Born: {selectedMember.birth_date}</p>
                )}
                <p className="text-slate-400 text-sm leading-relaxed">
                  {selectedMember.bio || "No biography available for this member."}
                </p>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      )}
    </div>
  );
}
