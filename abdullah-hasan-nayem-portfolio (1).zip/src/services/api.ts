const API_URL = '/api';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  return token ? { 'Authorization': `Bearer ${token}` } : {};
};

export const api = {
  // Auth
  login: async (credentials: any) => {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    localStorage.setItem('token', data.token);
    return data;
  },
  register: async (userData: any) => {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  me: async () => {
    const res = await fetch(`${API_URL}/auth/me`, {
      headers: getAuthHeader()
    });
    if (!res.ok) throw new Error('Not authenticated');
    return res.json();
  },
  updateProfile: async (userData: any) => {
    const res = await fetch(`${API_URL}/auth/update-profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(userData)
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  logout: () => {
    localStorage.removeItem('token');
  },

  // Projects
  getProjects: async () => {
    const res = await fetch(`${API_URL}/projects`);
    return res.json();
  },
  createProject: async (data: any) => {
    const res = await fetch(`${API_URL}/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  updateProject: async (id: any, data: any) => {
    const res = await fetch(`${API_URL}/projects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  deleteProject: async (id: any) => {
    await fetch(`${API_URL}/projects/${id}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
  },

  // Blogs
  getBlogs: async () => {
    const res = await fetch(`${API_URL}/blogs`);
    return res.json();
  },
  getBlog: async (id: any) => {
    const res = await fetch(`${API_URL}/blogs/${id}`);
    return res.json();
  },
  createBlog: async (data: any) => {
    const res = await fetch(`${API_URL}/blogs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  updateBlog: async (id: any, data: any) => {
    const res = await fetch(`${API_URL}/blogs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  deleteBlog: async (id: any) => {
    await fetch(`${API_URL}/blogs/${id}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
  },

  // Family
  getFamily: async () => {
    const res = await fetch(`${API_URL}/family`);
    return res.json();
  },
  createFamilyMember: async (data: any) => {
    const res = await fetch(`${API_URL}/family`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  updateFamilyMember: async (id: any, data: any) => {
    const res = await fetch(`${API_URL}/family/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  deleteFamilyMember: async (id: any) => {
    await fetch(`${API_URL}/family/${id}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
  },

  // Messages
  getMessages: async () => {
    const res = await fetch(`${API_URL}/messages`, {
      headers: getAuthHeader()
    });
    return res.json();
  },
  sendMessage: async (data: any) => {
    const res = await fetch(`${API_URL}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  markMessageRead: async (id: any) => {
    const res = await fetch(`${API_URL}/messages/${id}/read`, {
      method: 'PUT',
      headers: getAuthHeader()
    });
    return res.json();
  },
  deleteMessage: async (id: any) => {
    await fetch(`${API_URL}/messages/${id}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
  },

  // Users
  getUsers: async () => {
    const res = await fetch(`${API_URL}/users`, {
      headers: getAuthHeader()
    });
    return res.json();
  },
  updateUser: async (id: any, data: any) => {
    const res = await fetch(`${API_URL}/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  deleteUser: async (id: any) => {
    await fetch(`${API_URL}/users/${id}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
  },

  // Media
  getMedia: async () => {
    const response = await fetch(`${API_URL}/media`, {
      headers: getAuthHeader()
    });
    if (!response.ok) throw new Error('Failed to fetch media');
    return response.json();
  },

  uploadMedia: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${API_URL}/media/upload`, {
      method: 'POST',
      headers: getAuthHeader(), // Note: Don't set Content-Type for FormData
      body: formData,
    });
    if (!response.ok) throw new Error('Failed to upload media');
    return response.json();
  },

  deleteMedia: async (name: string) => {
    const response = await fetch(`${API_URL}/media/${name}`, {
      method: 'DELETE',
      headers: getAuthHeader()
    });
    if (!response.ok) throw new Error('Failed to delete media');
    return true;
  },

  // Settings
  getSettings: async (id: string) => {
    const response = await fetch(`${API_URL}/settings/${id}`, {
      headers: getAuthHeader()
    });
    if (!response.ok) throw new Error('Failed to fetch settings');
    return response.json();
  },

  updateSettings: async (id: string, data: any) => {
    const response = await fetch(`${API_URL}/settings/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update settings');
    return response.json();
  },

  getStats: async () => {
    const response = await fetch(`${API_URL}/stats`, {
      headers: getAuthHeader()
    });
    if (!response.ok) throw new Error('Failed to fetch stats');
    return response.json();
  }
};
