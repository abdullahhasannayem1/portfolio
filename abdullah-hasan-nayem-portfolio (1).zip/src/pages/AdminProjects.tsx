import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { Plus, Edit2, Trash2, X, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  techStack: string[];
  liveLink: string;
  githubLink: string;
  featured: boolean;
}

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    image: '',
    techStack: '',
    liveLink: '',
    githubLink: '',
    featured: false
  });

  const fetchProjects = async () => {
    try {
      const data = await api.getProjects();
      setProjects(data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleOpenModal = (project?: Project) => {
    if (project) {
      setEditingProject(project);
      setFormData({
        title: project.title,
        description: project.description,
        image: project.image || '',
        techStack: project.techStack?.join(', ') || '',
        liveLink: project.liveLink || '',
        githubLink: project.githubLink || '',
        featured: project.featured || false
      });
    } else {
      setEditingProject(null);
      setFormData({
        title: '',
        description: '',
        image: '',
        techStack: '',
        liveLink: '',
        githubLink: '',
        featured: false
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const projectData = {
      ...formData,
      techStack: formData.techStack.split(',').map(s => s.trim()).filter(s => s !== '')
    };

    try {
      if (editingProject) {
        await api.updateProject(editingProject.id, projectData);
      } else {
        await api.createProject(projectData);
      }
      setIsModalOpen(false);
      fetchProjects();
    } catch (error) {
      console.error('Error saving project:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      try {
        await api.deleteProject(id);
        fetchProjects();
      } catch (error) {
        console.error('Error deleting project:', error);
      }
    }
  };

  if (loading) return <div className="text-white">Loading projects...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">Manage Projects</h3>
        <button 
          onClick={() => handleOpenModal()}
          className="px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center space-x-2 hover:bg-blue-600 transition-all"
        >
          <Plus size={20} />
          <span>Add Project</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <GlassCard key={project.id} className="p-6">
            <div className="aspect-video rounded-xl overflow-hidden mb-4">
              <img 
                src={project.image || `https://picsum.photos/seed/${project.id}/400/250`} 
                alt={project.title} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <h4 className="text-lg font-bold text-white mb-2">{project.title}</h4>
            <p className="text-slate-500 text-xs mb-4 line-clamp-2">{project.description}</p>
            <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleOpenModal(project)}
                  className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
                >
                  <Edit2 size={16} />
                </button>
                <button 
                  onClick={() => handleDelete(project.id)}
                  className="p-2 hover:bg-red-400/10 rounded-lg text-red-400 hover:text-red-300 transition-all"
                >
                  <Trash2 size={16} />
                </button>
              </div>
              {project.featured && (
                <span className="text-[10px] uppercase font-bold text-accent bg-accent/10 px-2 py-1 rounded">Featured</span>
              )}
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="max-w-2xl w-full"
            >
              <GlassCard className="p-10">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-bold text-white">{editingProject ? 'Edit Project' : 'Add New Project'}</h3>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full text-slate-400">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Project Title</label>
                    <input 
                      type="text" 
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Description</label>
                    <textarea 
                      required
                      rows={3}
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Image URL</label>
                    <input 
                      type="text" 
                      value={formData.image}
                      onChange={(e) => setFormData({...formData, image: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Tech Stack (comma separated)</label>
                    <input 
                      type="text" 
                      value={formData.techStack}
                      onChange={(e) => setFormData({...formData, techStack: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                      placeholder="React, Firebase, Tailwind"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Live Link</label>
                    <input 
                      type="text" 
                      value={formData.liveLink}
                      onChange={(e) => setFormData({...formData, liveLink: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">GitHub Link</label>
                    <input 
                      type="text" 
                      value={formData.githubLink}
                      onChange={(e) => setFormData({...formData, githubLink: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="flex items-center space-x-3">
                    <input 
                      type="checkbox" 
                      id="featured"
                      checked={formData.featured}
                      onChange={(e) => setFormData({...formData, featured: e.target.checked})}
                      className="w-5 h-5 rounded border-white/10 bg-white/5 text-primary focus:ring-primary"
                    />
                    <label htmlFor="featured" className="text-sm text-slate-300 font-medium">Featured Project</label>
                  </div>

                  <div className="md:col-span-2 pt-4">
                    <button 
                      type="submit"
                      className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 transition-all"
                    >
                      <Save size={20} />
                      <span>{editingProject ? 'Update Project' : 'Save Project'}</span>
                    </button>
                  </div>
                </form>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
