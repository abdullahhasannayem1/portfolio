import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { Trash2, CheckCircle, Circle, Mail, Calendar } from 'lucide-react';
import { formatDate } from '../lib/utils';

interface Message {
  id: string;
  name: string;
  email: string;
  message: string;
  read: boolean;
  createdAt: any;
}

export default function AdminMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMessages = async () => {
    try {
      const data = await api.getMessages();
      setMessages(data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  const toggleRead = async (message: Message) => {
    try {
      await api.markMessageRead(message.id);
      fetchMessages();
    } catch (error) {
      console.error('Error updating message:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this message?')) {
      try {
        await api.deleteMessage(id);
        fetchMessages();
      } catch (error) {
        console.error('Error deleting message:', error);
      }
    }
  };

  if (loading) return <div className="text-white">Loading messages...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">Contact Messages</h3>
        <span className="px-4 py-1.5 glass rounded-full text-xs font-bold text-slate-400">
          {messages.filter(m => !m.read).length} Unread
        </span>
      </div>

      <div className="space-y-4">
        {messages.length > 0 ? (
          messages.map((msg) => (
            <GlassCard key={msg.id} className={msg.read ? 'opacity-60' : 'border-l-4 border-l-primary'}>
              <div className="flex flex-col md:flex-row justify-between gap-6">
                <div className="flex-grow">
                  <div className="flex items-center space-x-4 mb-3">
                    <h4 className="text-lg font-bold text-white">{msg.name}</h4>
                    <span className="text-slate-500 text-xs flex items-center space-x-1">
                      <Mail size={12} />
                      <span>{msg.email}</span>
                    </span>
                    <span className="text-slate-500 text-xs flex items-center space-x-1">
                      <Calendar size={12} />
                      <span>{formatDate(msg.createdAt)}</span>
                    </span>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed bg-white/5 p-4 rounded-xl border border-white/5">
                    {msg.message}
                  </p>
                </div>
                
                <div className="flex md:flex-col space-x-2 md:space-x-0 md:space-y-2 justify-end">
                  <button 
                    onClick={() => toggleRead(msg)}
                    className={`p-3 rounded-xl transition-all flex items-center justify-center ${
                      msg.read ? 'bg-white/5 text-slate-500 hover:bg-white/10' : 'bg-primary/10 text-primary hover:bg-primary/20'
                    }`}
                    title={msg.read ? 'Mark as Unread' : 'Mark as Read'}
                  >
                    {msg.read ? <Circle size={20} /> : <CheckCircle size={20} />}
                  </button>
                  <button 
                    onClick={() => handleDelete(msg.id)}
                    className="p-3 bg-red-400/10 text-red-400 hover:bg-red-400/20 rounded-xl transition-all flex items-center justify-center"
                    title="Delete Message"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
            </GlassCard>
          ))
        ) : (
          <div className="text-center py-20 text-slate-500">
            No messages found.
          </div>
        )}
      </div>
    </div>
  );
}
