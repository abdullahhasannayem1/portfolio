import { useState } from 'react';
import { useAuth } from '../AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import { LogIn, ArrowLeft } from 'lucide-react';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await login({ email, password });
      navigate('/admin');
    } catch (err: any) {
      setError('Invalid email or password');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      <div className="max-w-md w-full">
        <Link to="/" className="inline-flex items-center space-x-2 text-slate-500 hover:text-white transition-colors mb-8">
          <ArrowLeft size={18} />
          <span>Back to Site</span>
        </Link>
        
        <GlassCard className="p-10">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-2 tracking-tighter">Admin Login</h2>
            <p className="text-slate-500 text-sm">Secure access to your portfolio panel</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                placeholder="admin@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                placeholder="••••••••"
              />
            </div>

            {error && <p className="text-red-400 text-sm text-center font-medium">{error}</p>}

            <button 
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 transition-all disabled:opacity-50"
            >
              {loading ? <span>Authenticating...</span> : (
                <>
                  <span>Login</span>
                  <LogIn size={20} />
                </>
              )}
            </button>
          </form>
        </GlassCard>
      </div>
    </div>
  );
}
