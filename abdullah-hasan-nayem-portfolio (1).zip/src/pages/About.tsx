import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';

export default function About() {
  const skills = [
    { name: 'Frontend', items: ['React', 'Next.js', 'Tailwind CSS', 'Framer Motion', 'TypeScript'] },
    { name: 'Backend', items: ['Node.js', 'Express', 'Firebase', 'PostgreSQL', 'MongoDB'] },
    { name: 'Tools', items: ['Git', 'Docker', 'Vite', 'Figma', 'Postman'] },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16"
      >
        <h2 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter">
          About <span className="text-gradient">Me</span>
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 text-lg text-slate-400 leading-relaxed">
            <p>
              Hello! I'm Abdullah Hasan Nayem, a passionate developer and entrepreneur 
              from Sujanagar, Pabna, currently based in Magura Sadar. 
              I am a student of Computer Science and Technology, always eager to learn 
              and implement new technologies.
            </p>
            <p>
              My journey in tech started with a curiosity about how things work on the web. 
              Today, I specialize in building full-stack applications that are not only 
              functional but also visually appealing and user-friendly.
            </p>
            <p>
              Beyond coding, I am interested in entrepreneurship and how technology can 
              be used to solve real-world problems and create value for communities.
            </p>
          </div>
          <GlassCard className="aspect-square flex items-center justify-center overflow-hidden">
             <img 
               src="https://picsum.photos/seed/nayem/800/800" 
               alt="Abdullah Hasan Nayem" 
               className="w-full h-full object-cover rounded-xl"
               referrerPolicy="no-referrer"
             />
          </GlassCard>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {skills.map((skill, idx) => (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <GlassCard className="h-full">
              <h3 className="text-xl font-bold text-white mb-6 border-b border-white/10 pb-4">
                {skill.name}
              </h3>
              <div className="flex flex-wrap gap-2">
                {skill.items.map((item) => (
                  <span 
                    key={item} 
                    className="px-3 py-1 bg-white/5 rounded-full text-sm text-slate-300 border border-white/10"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
