import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import ReactMarkdown from 'react-markdown';
import { Calendar, Tag, ArrowLeft, User } from 'lucide-react';
import { formatDate } from '../lib/utils';
import GlassCard from '../components/GlassCard';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  author: string;
  image: string;
  createdAt: string;
}

export default function BlogDetails() {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      if (!id) return;
      try {
        const data = await api.getBlog(id);
        if (data) {
          setPost(data);
        }
      } catch (error) {
        console.error('Error fetching blog post:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPost();
  }, [id]);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-white">Loading...</div>;
  if (!post) return <div className="min-h-screen flex items-center justify-center text-white">Post not found.</div>;

  return (
    <div className="max-w-4xl mx-auto px-6 py-24">
      <Link to="/blog" className="inline-flex items-center space-x-2 text-slate-500 hover:text-white transition-colors mb-12">
        <ArrowLeft size={18} />
        <span>Back to Blog</span>
      </Link>

      <article>
        <div className="mb-12">
          <div className="flex items-center space-x-4 text-xs font-bold uppercase tracking-widest text-primary mb-6">
            <span>{post.author}</span>
            <span className="w-1 h-1 bg-white/20 rounded-full" />
            <div className="flex items-center space-x-1 text-slate-500">
              <Calendar size={12} />
              <span>{formatDate(post.createdAt)}</span>
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter leading-tight">
            {post.title}
          </h1>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-primary">
              <User size={24} />
            </div>
            <div>
              <p className="text-white font-bold">{post.author}</p>
              <p className="text-slate-500 text-xs uppercase tracking-widest">Author</p>
            </div>
          </div>
        </div>

        {post.image && (
          <div className="aspect-video rounded-3xl overflow-hidden mb-12 glass">
            <img 
              src={post.image} 
              alt={post.title} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        )}

        <GlassCard className="p-10 md:p-16">
          <div className="prose prose-invert prose-slate max-w-none">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>
        </GlassCard>
      </article>
    </div>
  );
}
