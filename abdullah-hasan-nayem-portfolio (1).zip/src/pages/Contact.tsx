import { useState } from 'react';
import { api } from '../services/api';
import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';
import { Send, Mail, Phone, MapPin } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '', subject: 'Contact Form Message' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    try {
      await api.sendMessage(formData);
      setStatus('success');
      setFormData({ name: '', email: '', message: '', subject: 'Contact Form Message' });
    } catch (error) {
      console.error('Error sending message:', error);
      setStatus('error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <h2 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter">
            Get in <span className="text-gradient">Touch</span>
          </h2>
          <p className="text-lg text-slate-400 mb-12 leading-relaxed">
            Have a project in mind or just want to say hello? 
            Feel free to reach out. I'm always open to discussing new projects, 
            creative ideas or opportunities to be part of your visions.
          </p>

          <div className="space-y-8">
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-primary">
                <Mail size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Email</h4>
                <p className="text-slate-400">abdullahhasannayem@gmail.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-secondary">
                <Phone size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Phone</h4>
                <p className="text-slate-400">+8801611997358</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-accent">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Location</h4>
                <p className="text-slate-400">Magura Sadar, Bangladesh</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <GlassCard className="p-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Email</label>
                <input 
                  type="email" 
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                  placeholder="your@email.com"
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Message</label>
                <textarea 
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all resize-none"
                  placeholder="Tell me about your project..."
                />
              </div>
              
              <button 
                type="submit"
                disabled={status === 'submitting'}
                className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 transition-all disabled:opacity-50"
              >
                {status === 'submitting' ? (
                  <span>Sending...</span>
                ) : (
                  <>
                    <span>Send Message</span>
                    <Send size={20} />
                  </>
                )}
              </button>

              {status === 'success' && (
                <p className="text-green-400 text-center font-medium">Message sent successfully!</p>
              )}
              {status === 'error' && (
                <p className="text-red-400 text-center font-medium">Something went wrong. Please try again.</p>
              )}
            </form>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}
