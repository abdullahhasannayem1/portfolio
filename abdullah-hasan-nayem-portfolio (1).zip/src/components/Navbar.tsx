import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { Menu, X, User, LogOut, LayoutDashboard } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { cn } from '../lib/utils';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { user, role, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Blog', path: '/blog' },
    { name: 'Family Tree', path: '/family-tree' },
    { name: 'Contact', path: '/contact' },
  ];

  const isAdmin = role === 'admin';

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4',
        scrolled ? 'glass-dark py-3' : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-gradient tracking-tighter">
          AHN.
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                'text-sm font-medium transition-colors hover:text-primary',
                location.pathname === link.path ? 'text-primary' : 'text-slate-300'
              )}
            >
              {link.name}
            </Link>
          ))}
          
          {user ? (
            <div className="flex items-center space-x-4 ml-4 pl-4 border-l border-white/10">
              {isAdmin && (
                <Link to="/admin" className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <LayoutDashboard size={18} className="text-slate-300" />
                </Link>
              )}
              <button 
                onClick={() => logout()}
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
                title="Logout"
              >
                <LogOut size={18} className="text-slate-300" />
              </button>
            </div>
          ) : (
            <Link 
              to="/admin/login" 
              className="ml-4 px-4 py-2 rounded-full glass hover:bg-white/20 transition-all text-sm font-medium"
            >
              Login
            </Link>
          )}
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-full left-0 right-0 glass-dark p-6 flex flex-col space-y-4"
        >
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className={cn(
                'text-lg font-medium',
                location.pathname === link.path ? 'text-primary' : 'text-slate-300'
              )}
            >
              {link.name}
            </Link>
          ))}
          {user && isAdmin && (
            <Link to="/admin" onClick={() => setIsOpen(false)} className="text-lg font-medium text-slate-300">
              Dashboard
            </Link>
          )}
          {user ? (
            <button 
              onClick={() => { logout(); setIsOpen(false); }}
              className="text-lg font-medium text-red-400 text-left"
            >
              Logout
            </button>
          ) : (
            <Link to="/admin/login" onClick={() => setIsOpen(false)} className="text-lg font-medium text-primary">
              Login
            </Link>
          )}
        </motion.div>
      )}
    </nav>
  );
}
