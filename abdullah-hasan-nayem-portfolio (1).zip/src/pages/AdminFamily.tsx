import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { Plus, Edit2, Trash2, X, Save, Upload, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FamilyMember {
  id: string;
  name: string;
  photo?: string;
  gender?: 'male' | 'female' | 'other';
  father_id?: string;
  mother_id?: string;
  spouse_id?: string;
  birth_date?: string;
  bio?: string;
}

export default function AdminFamily() {
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    photo: '',
    gender: 'male',
    father_id: '',
    mother_id: '',
    spouse_id: '',
    birth_date: '',
    bio: ''
  });

  const fetchMembers = async () => {
    try {
      const data = await api.getFamily();
      setMembers(data);
    } catch (error) {
      console.error('Error fetching members:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  const handleOpenModal = (member?: FamilyMember) => {
    if (member) {
      setEditingMember(member);
      setFormData({
        name: member.name,
        photo: member.photo || '',
        gender: member.gender || 'male',
        father_id: member.father_id || '',
        mother_id: member.mother_id || '',
        spouse_id: member.spouse_id || '',
        birth_date: member.birth_date || '',
        bio: member.bio || ''
      });
    } else {
      setEditingMember(null);
      setFormData({
        name: '',
        photo: '',
        gender: 'male',
        father_id: '',
        mother_id: '',
        spouse_id: '',
        birth_date: '',
        bio: ''
      });
    }
    setIsModalOpen(true);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const result = await api.uploadMedia(file);
      setFormData({ ...formData, photo: result.url });
    } catch (error) {
      console.error('Error uploading photo:', error);
      alert('Failed to upload photo');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingMember) {
        await api.updateFamilyMember(editingMember.id, formData);
      } else {
        await api.createFamilyMember(formData);
      }
      setIsModalOpen(false);
      fetchMembers();
    } catch (error) {
      console.error('Error saving member:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this family member?')) {
      try {
        await api.deleteFamilyMember(id);
        fetchMembers();
      } catch (error) {
        console.error('Error deleting member:', error);
      }
    }
  };

  if (loading) return <div className="text-white">Loading members...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">Manage Family Tree</h3>
        <button 
          onClick={() => handleOpenModal()}
          className="px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center space-x-2 hover:bg-blue-600 transition-all"
        >
          <Plus size={20} />
          <span>Add Member</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {members.map((member) => (
          <GlassCard key={member.id} className="p-6 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-primary mb-4">
              <img 
                src={member.photo || `https://picsum.photos/seed/${member.id}/100/100`} 
                alt={member.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <h4 className="text-white font-bold mb-1">{member.name}</h4>
            <p className="text-slate-500 text-[10px] uppercase tracking-widest mb-4">
              {members.find(m => m.id === member.father_id)?.name ? `Son of ${members.find(m => m.id === member.father_id)?.name}` : 'Root Member'}
            </p>
            
            <div className="flex space-x-2 mt-auto">
              <button 
                onClick={() => handleOpenModal(member)}
                className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
              >
                <Edit2 size={16} />
              </button>
              <button 
                onClick={() => handleDelete(member.id)}
                className="p-2 hover:bg-red-400/10 rounded-lg text-red-400 hover:text-red-300 transition-all"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="max-w-2xl w-full"
            >
              <GlassCard className="p-10">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-bold text-white">{editingMember ? 'Edit Member' : 'Add Family Member'}</h3>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full text-slate-400">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Photo</label>
                    <div className="flex items-center space-x-4">
                      <div className="w-20 h-20 rounded-xl glass overflow-hidden flex items-center justify-center border border-white/10">
                        {formData.photo ? (
                          <img src={formData.photo} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <Camera size={24} className="text-slate-500" />
                        )}
                      </div>
                      <div className="flex-1">
                        <label className="inline-flex items-center px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg cursor-pointer transition-all">
                          <Upload size={16} className="mr-2 text-primary" />
                          <span className="text-sm font-medium text-slate-300">
                            {uploading ? 'Uploading...' : 'Upload Photo'}
                          </span>
                          <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} disabled={uploading} />
                        </label>
                        <p className="text-[10px] text-slate-500 mt-2">Recommended: Square image, max 2MB</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Gender</label>
                    <select 
                      value={formData.gender}
                      onChange={(e) => setFormData({...formData, gender: e.target.value as any})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary appearance-none"
                    >
                      <option value="male" className="bg-slate-900">Male</option>
                      <option value="female" className="bg-slate-900">Female</option>
                      <option value="other" className="bg-slate-900">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Birth Date</label>
                    <input 
                      type="date" 
                      value={formData.birth_date}
                      onChange={(e) => setFormData({...formData, birth_date: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Father</label>
                    <select 
                      value={formData.father_id}
                      onChange={(e) => setFormData({...formData, father_id: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary appearance-none"
                    >
                      <option value="" className="bg-slate-900">None</option>
                      {members.filter(m => m.id !== editingMember?.id && m.gender === 'male').map(m => (
                        <option key={m.id} value={m.id} className="bg-slate-900">{m.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Mother</label>
                    <select 
                      value={formData.mother_id}
                      onChange={(e) => setFormData({...formData, mother_id: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary appearance-none"
                    >
                      <option value="" className="bg-slate-900">None</option>
                      {members.filter(m => m.id !== editingMember?.id && m.gender === 'female').map(m => (
                        <option key={m.id} value={m.id} className="bg-slate-900">{m.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Spouse</label>
                    <select 
                      value={formData.spouse_id}
                      onChange={(e) => setFormData({...formData, spouse_id: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary appearance-none"
                    >
                      <option value="" className="bg-slate-900">None</option>
                      {members.filter(m => m.id !== editingMember?.id).map(m => (
                        <option key={m.id} value={m.id} className="bg-slate-900">{m.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Biography</label>
                    <textarea 
                      rows={3}
                      value={formData.bio}
                      onChange={(e) => setFormData({...formData, bio: e.target.value})}
                      className="w-full px-4 py-3 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary resize-none"
                    />
                  </div>

                  <div className="md:col-span-2 pt-4">
                    <button 
                      type="submit"
                      className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 transition-all"
                    >
                      <Save size={20} />
                      <span>{editingMember ? 'Update Member' : 'Save Member'}</span>
                    </button>
                  </div>
                </form>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
